#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov 22 11:54:04 2020

@author: jiangtao
"""

# -*- coding: utf-8 -*-
import tensorflow as tf
import numpy as np
import os
import matplotlib.pyplot as plt
from matplotlib import gridspec
from RX import RX
from AUC import AUC_PD_PF
from AUC3D import false_alarm_rate
from scipy import misc
from scipy.io import loadmat
import scipy.io as scio
import cv2
import sys
import h5py
import json

# Get the HSI data
dataset = 'sandiego_sub'
# dataset = 'abu-airport-4'
#dataset = 'abu-urban-3'
# dataset = 'sandiego1'


hyp_img = loadmat('./data/'+dataset+'.mat')#输入deta=0.01，抑制背景
# data_orig = hyp_img['data_N'][:]
data_orig = hyp_img['data'][:]
data_orig = data_orig.astype(np.float32)
label = hyp_img['map']
# label = hyp_img['groundtruth']
row_dim = data_orig.shape[0]
line_dim = data_orig.shape[1]
spectral_dim = data_orig.shape[2]
num_samples = row_dim*line_dim
data_norm = 2*((data_orig - data_orig.min()) / (data_orig.max() -data_orig.min())) - 1
data = np.reshape(data_norm,[num_samples,spectral_dim])
z_dim = 20
# backgroundfile = loadmat('/home/amax/NewDisk4T/jt/weaklyAD-sparseNet/2.network/data/'+dataset+'-newB.mat')
# newB = backgroundfile['newB'][:]
# newB_norm = 2*((newB - newB.min()) / (newB.max() - newB.min())) - 1
# data = np.reshape(data_norm,[num_samples,spectral_dim])
# newB_samples = newB.shape[0]
# newB_spectral = newB.shape[1]
# newB = newB_norm .astype(np.float32)

# Get the new HSI background data
backgroundfile = './data/'+dataset+'-newB.mat'
backgroundfile = h5py.File(backgroundfile)
newB = backgroundfile['newB'][:]
newB = newB.transpose(1,0)
newB_norm = 2*((newB - newB.min()) / (newB.max() - newB.min())) - 1
newB_samples = newB.shape[0]
newB_spectral = newB.shape[1]
newB = newB_norm .astype(np.float32)
n_hidden = spectral_dim
input_dim = spectral_dim

results_path = './Results/sparseHAD/'+dataset

## Get the HSI data
#hyp_img_gabor = '/home/amax/NewDisk4T/jt/gaborAD/2.network/data/abu-airport-4-gabor.mat'#输入deta=0.01，抑制背景
#hyp_img_gabor = h5py.File(hyp_img_gabor)
#data_orig_gabor = hyp_img_gabor['img3D'][:]
#data_orig_gabor = data_orig_gabor.astype(np.float32)
#data_orig_gabor = data_orig_gabor.transpose(2,1,0)
#row_dim = data_orig_gabor.shape[0]
#line_dim = data_orig_gabor.shape[1]
#spectral_dim = data_orig_gabor.shape[2]
#num_samples = row_dim*line_dim
#data_norm = 2*((data_orig_gabor - data_orig_gabor.min()) / (data_orig_gabor.max() -data_orig_gabor.min())) - 1
#data = np.reshape(data_norm,[num_samples,spectral_dim])
#img1 = data_orig_gabor[:,:,20]        
#plt.imshow(img1, cmap='gray')
#plt.imshow(img1)
#plt.colorbar()
#plt.show()
#
#input_dim = spectral_dim
#
#results_path = './results/abu-airport-4'

#load graph and parameters
with tf.Session() as sess:
    saver = tf.train.import_meta_graph('./model/model.meta')
    saver.restore(sess,save_path=tf.train.latest_checkpoint('./model'))
    #accessing the placeholders variables and create the feed-dict as the new values for placeholders.
    graph = tf.get_default_graph()
    
    originalHSI = graph.get_tensor_by_name("Decoder_input:0")
    HSI_EnOut = graph.get_tensor_by_name("gen__1/Encoder/e_latent_variable/matmul_1:0")
    HSI_DeOut = graph.get_tensor_by_name("gen__1/tied_weight_ae/eout:0")
    HSI_EnOut_z = graph.get_tensor_by_name("gen__1/tied_weight_ae/dout:0")

 
#    Encoder_out,Decoder_out,Encoder_out_z = sess.run(HSI_EnOut,HSI_DeOut,HSI_EnOut_z, feed_dict={originalHSI:data}) 
    Encoder_out = sess.run(HSI_EnOut, feed_dict={originalHSI:data})
    Encoder_out_z = sess.run(HSI_EnOut_z, feed_dict={originalHSI:data})
    #HSI_encoder_output-HSI_encoder_output_z 
    anomaly_score = np.abs(Encoder_out_z-Encoder_out)
    anomaly_score2D = ((anomaly_score - anomaly_score.min())/(anomaly_score.max() -anomaly_score.min()))
    anomaly_score3D = np.reshape(anomaly_score2D,[row_dim,line_dim,z_dim])
    
    recon_results =  './Results/'+dataset+'-sparseGAN.mat'
    scio.savemat(recon_results,{'anomaly':anomaly_score3D})       
    img = anomaly_score3D[:,:,15]        
    plt.imshow(img)
    plt.colorbar()
    plt.title("anomaly band 15")
    plt.show()
    #RX
    anomaly_rx_out = RX(anomaly_score3D)
    RX_results = './Results/'+dataset+'-sparseGAN-rx.mat'
    scio.savemat(RX_results,{'anomaly_RX_out':anomaly_rx_out})
    # visualization        
    plt.figure()
    plt.imshow(anomaly_rx_out)
    savepath = './Results/'+dataset+'-sparseGAN-rx_out.png'
    plt.savefig(savepath) 
    plt.title("anomaly rx")
    plt.show()
#    #auc
#    predictions = np.reshape(anomaly_rx_out, num_samples)
#    mask = np.reshape(label, num_samples)
#    auc_PD_PF,PF,PD = AUC_PD_PF(predictions,mask)
#    PD_PF_auc, PF_tau_auc = false_alarm_rate(mask,predictions)
#    plt.plot(PF, PD)
#    plt.text(0.6,0.7,'AUC value : %f'%auc_PD_PF) 
#    savepath = './Results/'+dataset+'-sparseNet-anomaly-rx_out-auc.png'
#    plt.savefig(savepath) 
#    plt.title("anomaly")
#    plt.show()
#    print('AUC value of (PF,PD):', [auc_PD_PF])	   
#    print('AUC3D value of (PF,PD):', [PD_PF_auc])	 
#    print('AUC3D value of (PF,tau):', [PF_tau_auc])	